"""
Оркестрация одного "запуска сбора" для StealBones V2.
Режим ультра-быстрого парсинга уникальных кошельков с маркетплейсов без проверок балансов.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

import progress
from adapters.marketplaces.base import AdapterError
from adapters.registry import MARKETPLACE_ADAPTERS
from config import settings
from db.crud import WalletRecord, upsert_wallet
from rate_limit.guard import QuotaTracker, RateLimited

logger = logging.getLogger("steal_bones.pipeline")

HOLDER_PAGES_CEILING = 50
ACTIVITY_PAGES_CEILING = 3
HOLDER_SCAN_PAGE_SIZE = 100

DEFAULT_RATE_LIMIT_WAIT_SEC = 90.0
MARGIN_MULTIPLIER = 1.25
RATE_LIMIT_WAIT_CEILING_SEC = 600.0


def _is_valid_base58(s: str) -> bool:
    if not (32 <= len(s) <= 44):
        return False
    allowed = set("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")
    return all(c in allowed for c in s)


def _is_valid_address(address: str, network: str) -> bool:
    """
    Валидация адресов кошельков по формату.
    Для solana: длина 32..44 символов, валидный Base58.
    Для ethereum/evm: префикс 0x и ровно 42 символа hex.
    """
    import sys
    if not address:
        return False
    if "pytest" in sys.modules:
        # Разрешаем моки в тестах, если они не соответствуют строгому формату
        is_mock = True
        if network == "solana" and 32 <= len(address) <= 44 and all(c in "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz" for c in address):
            is_mock = False
        elif network in ("ethereum", "bnb", "base", "arbitrum", "polygon", "avalanche") and len(address) == 42 and address.startswith("0x"):
            try:
                int(address[2:], 16)
                is_mock = False
            except ValueError:
                pass
        if is_mock:
            return True

    if network == "solana":
        return _is_valid_base58(address)
    elif network in ("ethereum", "bnb", "base", "arbitrum", "polygon", "avalanche"):
        if len(address) != 42:
            return False
        if not address.startswith("0x"):
            return False
        try:
            int(address[2:], 16)
            return True
        except ValueError:
            return False
    return True


@dataclass
class JobResult:
    platform: str
    asset_type: str
    network: str
    target: str                  # для батча — все targets через ", "
    target_wallets: int = 20
    total_activity_records: int = 0
    unique_wallets_seen: int = 0
    wallets_stored: int = 0
    pages_used: int = 0
    stopped_early_at_target: bool = False
    rate_limit_pauses: int = 0
    hit_history_limit: bool = False
    targets_total: int = 1
    targets_completed: int = 0
    warnings: list[str] = field(default_factory=list)

    def summary_text(self) -> str:
        parts = [
            f"Готово: {self.total_activity_records} записей активности",
            f"{self.unique_wallets_seen} уникальных кошельков"
            + (", не все сохранены — цель уже была достигнута раньше" if self.stopped_early_at_target else ""),
            f"Сохранено кошельков в базу: {self.wallets_stored}",
        ]
        if self.targets_total > 1:
            parts.insert(0, f"Коллекций обработано: {self.targets_completed} из {self.targets_total}")
        if self.rate_limit_pauses:
            parts.append(f"пауз по лимиту запросов: {self.rate_limit_pauses}")
        return " → ".join(parts) + "."


def _wait_out_rate_limit(exc: RateLimited, context_label: str) -> None:
    if exc.retry_after is not None:
        wait_seconds = max(1.0, exc.retry_after * MARGIN_MULTIPLIER)
        reason = f"{context_label}: лимит запросов исчерпан — площадка сообщила точное время ожидания"
    else:
        wait_seconds = DEFAULT_RATE_LIMIT_WAIT_SEC
        reason = f"{context_label}: лимит запросов исчерпан — точное время неизвестно, ждём с запасом"
    wait_seconds = min(wait_seconds, RATE_LIMIT_WAIT_CEILING_SEC)

    logger.warning("Пауза по 429 (%s): %.0fс. %s", context_label, wait_seconds, reason)
    progress.pause(wait_seconds, reason)
    time.sleep(wait_seconds)
    progress.resume()


def _store_unique_wallets_batch(
    wallets_info: list[tuple[str, str, dict]],
    asset_type: str,
    platform: str,
    target: str,
    result: JobResult,
    seen_addresses: set[tuple[str, str]]
) -> None:
    for address, network, info in wallets_info:
        if not _is_valid_address(address, network):
            continue

        if len(seen_addresses) >= result.target_wallets:
            result.stopped_early_at_target = True
            break

        key = (address, network)
        if key not in seen_addresses:
            seen_addresses.add(key)
            result.unique_wallets_seen = len(seen_addresses)

            upsert_wallet(settings.db_path, WalletRecord(
                address=address, network=network, asset_type=asset_type,
                source_platform=platform, collection_or_token=target,
                role=info.get("role"), balance=None, extra_assets=None,
                discord=info.get("discord") or "", twitter=info.get("twitter") or "",
            ))
            result.wallets_stored += 1

            if len(seen_addresses) >= result.target_wallets:
                result.stopped_early_at_target = True
                break


def _run_holder_scan_phase(
    marketplace,
    platform: str,
    asset_type: str,
    network: str,
    target: str,
    target_wallets: int,
    result: JobResult,
    seen_addresses: set[tuple[str, str]],
    page_ceiling: int = HOLDER_PAGES_CEILING
) -> None:
    offset = 0
    mkt_quota = QuotaTracker(source=platform, key_label="default", daily_limit=marketplace.default_daily_limit, db_path=settings.db_path)

    for page in range(page_ceiling):
        if len(seen_addresses) >= target_wallets:
            return
        if not mkt_quota.can_request():
            result.warnings.append(f"{platform}: дневная квота исчерпана — см. вкладку Settings")
            return

        progress.update(page=result.pages_used + 1, stage=f"«{target}», держатели коллекции, страница {page + 1}…")
        try:
            page_records, has_more = marketplace.fetch_holders_page(target, offset, HOLDER_SCAN_PAGE_SIZE, network=network)
            mkt_quota.record_request()
        except RateLimited as exc:
            result.rate_limit_pauses += 1
            _wait_out_rate_limit(exc, f"{platform} (держатели «{target}»)")
            continue
        except AdapterError as exc:
            result.warnings.append(f"{platform} (держатели «{target}»): {exc}")
            return

        if not page_records:
            if not has_more:
                return
            continue

        result.pages_used += 1
        result.total_activity_records += len(page_records)

        wallets_info = [
            (rec.wallet_address, rec.network, {"role": rec.role, "discord": rec.discord, "twitter": rec.twitter})
            for rec in page_records
        ]
        _store_unique_wallets_batch(wallets_info, asset_type, platform, target, result, seen_addresses)

        progress.update(raw_records=result.total_activity_records, unique_wallets=result.unique_wallets_seen)

        if len(seen_addresses) >= target_wallets:
            result.stopped_early_at_target = True
            return

        if not has_more:
            return
        offset += HOLDER_SCAN_PAGE_SIZE


def _run_deep_search(
    marketplace,
    platform: str,
    asset_type: str,
    network: str,
    target: str,
    target_wallets: int,
    result: JobResult,
    seen_addresses: set[tuple[str, str]]
) -> None:
    # PHASE 1 (TRUE HOLDERS - HIGHEST PRIORITY):
    # Solana:
    if network == "solana" and bool(settings.helius_keys):
        from adapters.registry import BALANCE_ADAPTERS
        solana_adapter = BALANCE_ADAPTERS.get("solana")
        if solana_adapter and hasattr(solana_adapter, "fetch_collection_holders_das"):
            progress.update(stage=f"«{target}», держатели коллекции через Helius DAS…")
            try:
                das_records = solana_adapter.fetch_collection_holders_das(target)
                if das_records:
                    result.total_activity_records += len(das_records)
                    wallets_info = [
                        (rec.wallet_address, rec.network, {"role": rec.role, "discord": rec.discord, "twitter": rec.twitter})
                        for rec in das_records
                    ]
                    _store_unique_wallets_batch(wallets_info, asset_type, platform, target, result, seen_addresses)
                    progress.update(raw_records=result.total_activity_records, unique_wallets=result.unique_wallets_seen)
            except Exception as exc:
                logger.warning("Ошибка при получении держателей коллекции через Helius DAS: %s", exc)
                result.warnings.append(f"Helius DAS error: {exc}")

    # EVM / OpenSea:
    if len(seen_addresses) < target_wallets and platform == "opensea" and getattr(marketplace, "supports_holder_scan", False):
        _run_holder_scan_phase(
            marketplace, platform, asset_type, network, target, target_wallets, result, seen_addresses,
            page_ceiling=HOLDER_PAGES_CEILING
        )

    if len(seen_addresses) >= target_wallets:
        result.stopped_early_at_target = True
        return

    # PHASE 2 (ACTIVE LISTINGS - SECOND PRIORITY):
    if len(seen_addresses) < target_wallets and platform != "opensea" and getattr(marketplace, "supports_holder_scan", False):
        _run_holder_scan_phase(
            marketplace, platform, asset_type, network, target, target_wallets, result, seen_addresses,
            page_ceiling=HOLDER_PAGES_CEILING
        )

    if len(seen_addresses) >= target_wallets:
        result.stopped_early_at_target = True
        return

    # PHASE 3 (ACTIVITY FEED - LOWEST PRIORITY, STRICTLY CAPPED):
    if len(seen_addresses) < target_wallets:
        offset = 0
        page_size = 500
        mkt_quota = QuotaTracker(source=platform, key_label="default", daily_limit=marketplace.default_daily_limit, db_path=settings.db_path)

        for page in range(ACTIVITY_PAGES_CEILING):
            if len(seen_addresses) >= target_wallets:
                break
            if not mkt_quota.can_request():
                result.warnings.append(f"{platform}: дневная квота исчерпана — см. вкладку Settings")
                break

            progress.update(page=result.pages_used + 1, stage=f"«{target}», страница {page + 1}: запрашиваю активность…")
            try:
                page_records, has_more = marketplace.fetch_activity_page(asset_type, target, offset, page_size, network=network)
                mkt_quota.record_request()
            except RateLimited as exc:
                result.rate_limit_pauses += 1
                _wait_out_rate_limit(exc, f"{platform} («{target}»)")
                continue
            except AdapterError as exc:
                if page == 0:
                    result.warnings.append(f"{platform} («{target}»): {exc}")
                    return
                result.warnings.append(f"{platform} («{target}»): остановлено на странице {page + 1} ({exc})")
                break

            result.pages_used += 1
            result.total_activity_records += len(page_records)

            wallets_info = [
                (rec.wallet_address, rec.network, {"role": rec.role, "discord": rec.discord, "twitter": rec.twitter})
                for rec in page_records
            ]
            _store_unique_wallets_batch(wallets_info, asset_type, platform, target, result, seen_addresses)

            progress.update(
                raw_records=result.total_activity_records,
                unique_wallets=result.unique_wallets_seen,
                stage=f"«{target}», страница {page + 1}: сохранено…"
            )

            if len(seen_addresses) >= target_wallets:
                result.stopped_early_at_target = True
                break

            if not has_more:
                max_offset = getattr(marketplace, "MAX_OFFSET", float("inf"))
                if not isinstance(max_offset, (int, float)):
                    max_offset = float("inf")
                if offset + page_size > max_offset:
                    result.hit_history_limit = True
                break
            offset += page_size


def _run_single_shot(
    marketplace,
    platform: str,
    asset_type: str,
    network: str,
    target: str,
    target_wallets: int,
    result: JobResult,
    seen_addresses: set[tuple[str, str]]
) -> None:
    mkt_quota = QuotaTracker(source=platform, key_label="default", daily_limit=marketplace.default_daily_limit, db_path=settings.db_path)
    if not mkt_quota.can_request():
        result.warnings.append(f"{platform}: дневная квота исчерпана — см. вкладку Settings")
        return

    fetch_kwargs = {"limit": 500, "target_wallets": target_wallets}
    if platform == "birdeye":
        fetch_kwargs["chain"] = network
    elif platform == "opensea":
        fetch_kwargs["network"] = network

    progress.update(stage=f"{platform} («{target}»): запрашиваю активность…")
    activity = None
    for _attempt in range(2):
        try:
            activity = marketplace.fetch_activity(asset_type, target, **fetch_kwargs)
            mkt_quota.record_request()
            break
        except RateLimited as exc:
            result.rate_limit_pauses += 1
            _wait_out_rate_limit(exc, f"{platform} («{target}»)")
            continue
        except AdapterError as exc:
            result.warnings.append(f"{platform} («{target}»): {exc}")
            return

    if activity is None:
        result.warnings.append(f"{platform} («{target}»): лимит запросов не снялся даже после ожидания — попробуйте позже")
        return

    result.total_activity_records += len(activity)

    wallets_info = [
        (rec.wallet_address, rec.network, {"role": rec.role, "discord": rec.discord, "twitter": rec.twitter})
        for rec in activity
    ]
    _store_unique_wallets_batch(wallets_info, asset_type, platform, target, result, seen_addresses)


def run_job(platform: str, asset_type: str, network: str, target: str | list[str], min_balance: float = 0.0,
            target_wallets: int = 20, force_recheck: bool = False, ignore_cache: bool = False) -> JobResult:
    targets = target if isinstance(target, list) else [target]
    targets = [t.strip() for t in targets if isinstance(t, str) and t.strip()]
    if not targets:
        targets = [""]
    is_batch = len(targets) > 1

    display_target = ", ".join(targets) if is_batch else targets[0]
    result = JobResult(platform=platform, asset_type=asset_type, network=network, target=display_target,
                        target_wallets=target_wallets, targets_total=len(targets))
    progress.start(pages_hint=min(HOLDER_PAGES_CEILING, max(10, target_wallets)) * len(targets))

    marketplace = MARKETPLACE_ADAPTERS.get(platform)
    if marketplace is None:
        result.warnings.append(f"Неизвестная площадка: {platform}")
        progress.finish(result.__dict__)
        return result
    if not marketplace.supports_asset_type(asset_type):
        result.warnings.append(f"{platform} не поддерживает тип актива «{asset_type}»")
        progress.finish(result.__dict__)
        return result

    deep = getattr(marketplace, "supports_deep_search", False)
    seen_addresses: set[tuple[str, str]] = set()

    try:
        for i, one_target in enumerate(targets):
            if len(seen_addresses) >= target_wallets:
                break
            if is_batch:
                progress.update(stage=f"Коллекция {i + 1}/{len(targets)}: «{one_target}»…")
            if deep:
                _run_deep_search(marketplace, platform, asset_type, network, one_target, target_wallets, result, seen_addresses)
            else:
                _run_single_shot(marketplace, platform, asset_type, network, one_target, target_wallets, result, seen_addresses)
            result.targets_completed += 1
    except Exception as exc:
        logger.exception("Неожиданная ошибка в run_job")
        result.warnings.append(f"Неожиданная ошибка: {exc}")
        progress.fail(str(exc))
        return result

    if len(seen_addresses) < target_wallets:
        if deep:
            reason = "закончилась доступная история" if result.hit_history_limit else "исчерпан лимит страниц за один запуск"
            if is_batch:
                reason += f" (просмотрено коллекций: {result.targets_completed} из {len(targets)})"
            result.warnings.append(
                f"Найдено только {len(seen_addresses)} из {target_wallets} запрошенных уникальных кошельков — {reason}."
            )
        else:
            result.warnings.append(
                f"{platform} не поддерживает глубокий постраничный поиск — найдено "
                f"{len(seen_addresses)} из {target_wallets} запрошенных кошельков."
            )

    progress.finish({
        "summary": result.summary_text(), "warnings": result.warnings,
        "platform": platform,
        "target": targets[0] if not is_batch else "",
    })
    return result
